/*
  A minimal example for using LineChart.js
  Sparisoma Viridi

	20140410
	Create in HTML format (example1.html).
	20180224
	Rename to JS but not yet worked.
*/

// 20180224.0710 !ok
function test_linechart() {
/*
<meta charset="utf-8"/>
<canvas id="canvas" width="400" height="300" style="border:1px dashed #88aa88"></canvas>
<script src="LineChart.js"></script>

<script>
var lchart = new lineChart(document.getElementById("canvas").getContext("2d"));

var options = {
	xmin: -1,
	xmax: 9,
	ymin: -4,
	ymax: 20,
	xtics: 1,
	ytics: 4,
	xlabel: "t",
	ylabel: "x"
};

var data = [
	{
		lineColor: "rgba(255, 0, 0, 0.5)",
		lineWidth: "2",
		pointLineColor: "rgba(255, 0, 127, 0.8)",
		pointFillColor: "rgba(255, 127, 0, 0.6)",
		pointSize: "8",
		pointType: "0",
		datax: [0, 1, 2, 3, 4, 5, 6, 7, 8],
		datay: [0, 2, 4, 6, 8, 10, 12, 14, 16]
	},
	{
		lineColor: "rgba(0, 0, 255, 0.5)",
		lineWidth: "2",
		pointLineColor: "rgba(127, 0, 255, 0.8)",
		pointFillColor: "rgba(0, 127, 255, 0.6)",
		pointSize: "8",
		pointType: "1",
		datax: [0, 1, 2, 3, 4, 5, 6, 7, 8],
		datay: [0, 6, 12, 15, 16, 15, 12, 6, 0]
	}
];

var myline = new lchart.line(data, options);
</script>
*/	
}
